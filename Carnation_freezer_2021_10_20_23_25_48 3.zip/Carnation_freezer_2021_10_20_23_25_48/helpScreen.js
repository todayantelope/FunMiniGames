function setup(){
createCanvas(400, 500);
textSize(50);
text("WELCOME TO WALDO GAME");






}