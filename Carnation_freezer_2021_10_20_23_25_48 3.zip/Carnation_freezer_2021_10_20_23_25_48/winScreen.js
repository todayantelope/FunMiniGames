var num = 0;
function setup(){
    createCanvas(400, 500);
    background("Green");
    textSize(50);
    text("GOOD JOB!!!",50 ,250 );






}
function mousePressed(){
    let c = get(mouseX, mouseY);
    print(c);

    if(c == [255, 140, 0, 255].toString()){
    
        num = 0; 
       
      }







}
function draw(){
    let r = color(255, 0, 0);
    let y = color(255,255,0);
    let b = color(30,144,255);
    let o = color(255,140,0);
    let v = color(0,255,255);
    let s = color(192,192,192);
    if(num == 0){
   
        window.location = "whereswaldo.html";
             
      }
      if(num == 2){
    
       
        fill(o);
        rect(190, 420, 100, 50);
       
        fill(0,0,0)
        textSize(32);
        text('Home', 200, 450);

      }




}